public class Main {

    public static void main(String[] args) {

        10.00);

        Worker worker2 = new Worker("lucy", 17, 1951,
                19.00);

        Worker worker3 = new Worker("mike", 33, 1990,
                18.00);

//Create SalaryWorkers

        SalaryWorker salaryWorker1= new

                SalaryWorker("rock", 8, 1893, 2000.00);

        SalaryWorker salaryWorker2 = new

                SalaryWorker("brian", 29, 1794, 2500.00);

        SalaryWorker salaryWorker3 = new

                SalaryWorker("cash", 9, 2001, 3000.00);

//Add Workers and SalaryWorkers to ArrayList
        ArrayList<Worker> workers = new

                ArrayList<Worker>();

        workers.add(worker1);
        workers.add(worker2);

        workers.add(worker3);

        workers.add(salaryWorker1);
        workers.add(salaryWorker2);

        workers.add(salaryWorker3);

//Loop through ArrayList and print out each worker

        for (Worker w: workers) {
            System.out.println(w.toString());

        }

    }
