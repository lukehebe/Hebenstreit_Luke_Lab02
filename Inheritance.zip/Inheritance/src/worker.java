public class Worker extends Person {
    private double hourly PayRate;

    public Worker(String name, int age, double
            hourly PayRate) {
        super(name, age);
        this.hourly Pay Rate = hourly PayRate;

    }
    public double calculate Weekly Pay(double
                                               hoursWorked) {
        double totalPay;

        hours

        if (hoursWorked <= 40) {

            totalPay = hoursWorked * hourlyPayRate;

        }

        else {

            double overtimeHours = hoursWorked - 40;

            double overtime Pay = overtimeHours *

                    (hourlyPayRate * 1.5);

            double regularPay = 40* hourly PayRate;

            totalPay = overtime Pay + regularPay;

        }

        return totalPay;

    }

    public String displayWeekly Pay(double
                                                hoursWorked) {

        double totalPay;

        double regularHours;

        double overtimeHours;

        double regularPay;

        double overtimePay;

        hours

        if (hoursWorked <= 40) {
            totalPay = hoursWorked * hourly Pay Rate;
            regularHours = hoursWorked;
            overtime Hours = 0;
            regularPay = totalPay;
            overtime Pay = 0;
        }
        else {

            double overtimeHours = hoursWorked - 40;

            double overtime Pay = overtime Hours *
                    (hourlyPayRate * 1.5);

            double regularPay = 40* hourlyPayRate;

            totalPay = overtime Pay + regularPay;

            regularHours = 40;

            regularPay = regularHours* hourlyPayRate;

            overtimePay = overtime Hours* (hourly PayRate *

                    1.5);

        }

        return "Regular Hours: "+ regularHours + " hours,
        Regular Pay: $" + regularPay

                + "\nOvertime Hours: " + overtime Hours + " hours,

        Overtime Pay: $" + overtimePay

                + "\nTotal Pay: $" + totalPay;

    }

}
