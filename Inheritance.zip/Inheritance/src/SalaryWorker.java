public class SalaryWorker extends Worker{
    private double annualSalary;

    public SalaryWorker(String name, int idNumber,
                        double annualSalary){

        super(name,idNumber);
        this.annualSalary annualSalary;

    }

    public double calculate Weekly Pay(double
                                               hoursWorked){
        double weekly Pay = annualSalary/52;
        return weeklyPay;

    }
    public void displayWeeklyPay(){double weekly Pay = calculate Weekly Pay(0);
        System.out.println("This is a fraction of the yearly " +
                "salary: "+weeklyPay);

    }

}
